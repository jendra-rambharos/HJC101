document.write("<p>Hello, there!</p>");
